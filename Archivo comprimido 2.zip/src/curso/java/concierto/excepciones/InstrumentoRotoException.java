package curso.java.concierto.excepciones;

public class InstrumentoRotoException extends Exception {

}
