package curso.java.concierto.musicos;


public interface MusicoInterface
{
	public void tocar() ;
}
