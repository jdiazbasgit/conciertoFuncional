package curso.java.concierto.instrumentos;

public interface InstrumentoInterface {
	public String sonar();
}
